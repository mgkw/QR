let video = document.getElementById('video');
let canvas = document.getElementById('overlay');
let ctx = canvas.getContext('2d');
let statusBox = document.getElementById('status-box');
let flashButton = document.getElementById('flashButton');
let stopButton = document.getElementById('stopButton');
let startButton = document.getElementById('startButton');

let isScanning = false;
let stream = null;
let track = null;
let isFlashOn = false;
let lastScanTime = 0;
let barcodeData = {}; // سيتم تحميله من قاعدة البيانات عند بدء التشغيل
let successSound = new Audio('/static/success.mp3');

// ✅ **جلب البيانات المخزنة من قاعدة البيانات عند تحميل الصفحة**
async function loadBarcodeData() {
    try {
        let response = await fetch("/get_scanned_barcodes");
        let data = await response.json();
        barcodeData = data;
        console.log("📥 تم تحميل بيانات الباركود من قاعدة البيانات:", barcodeData);
    } catch (error) {
        console.error("❌ خطأ في تحميل بيانات الباركود:", error);
    }
}

// ✅ تشغيل الكاميرا
async function startCamera() {
    try {
        if (stream) return;

        let constraints = {
            video: { facingMode: "environment", width: { ideal: 1280 }, height: { ideal: 720 } }
        };

        stream = await navigator.mediaDevices.getUserMedia(constraints);
        video.srcObject = stream;
        track = stream.getVideoTracks()[0];

        video.onloadedmetadata = () => {
            video.play();
            adjustCanvasSize();
        };

        console.log("✅ الكاميرا تعمل بنجاح!");
        startScanning();
    } catch (error) {
        console.error("❌ خطأ في تشغيل الكاميرا:", error);
        alert("⚠️ لا يمكن الوصول إلى الكاميرا! تأكد من منح الأذونات.");
    }
}

// ✅ ضبط `canvas` ليطابق `video`
function adjustCanvasSize() {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
}

// ✅ إيقاف الكاميرا والفلاش عند الحاجة
function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        video.srcObject = null;
        stream = null;
        track = null;
        isFlashOn = false;
        flashButton.textContent = "🔦 تشغيل الفلاش";
        console.log("📷 تم إيقاف الكاميرا.");
    }
}

// ✅ تشغيل/إيقاف الفلاش
flashButton.onclick = () => {
    if (track && track.getCapabilities().torch) {
        isFlashOn = !isFlashOn;
        track.applyConstraints({ advanced: [{ torch: isFlashOn }] })
            .then(() => {
                flashButton.textContent = isFlashOn ? "🔦 إيقاف الفلاش" : "🔦 تشغيل الفلاش";
            })
            .catch(error => {
                console.error("❌ خطأ في التحكم بالفلاش:", error);
                alert("⚠️ لا يمكن التحكم بالفلاش على هذا الجهاز!");
                isFlashOn = false;
            });
    } else {
        alert("❌ الجهاز لا يدعم تشغيل الفلاش!");
    }
};

// ✅ تشغيل وإيقاف المسح
startButton.onclick = startScanning;
stopButton.onclick = stopScanning;

function startScanning() {
    if (isScanning) return;
    isScanning = true;
    requestAnimationFrame(scan);
}

function stopScanning() {
    isScanning = false;
}

// ✅ تشغيل الكاميرا عند تحميل الصفحة واسترجاع بيانات الباركود
window.onload = async () => {
    stopCamera();
    await loadBarcodeData(); // تحميل البيانات من قاعدة البيانات
    startCamera();
};

// ✅ إيقاف الكاميرا عند مغادرة الصفحة
window.addEventListener("beforeunload", () => {
    stopCamera();
    stopScanning();
});

// ✅ مسح الباركود وتحديده على الشاشة
function scan() {
    if (!isScanning) return;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

        let imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        let code = jsQR(imageData.data, imageData.width, imageData.height, { inversionAttempts: "dontInvert" });

        if (code) {
            let barcode = code.data.trim();
            let currentTime = new Date().getTime();

            // ✅ تحقق مما إذا كان الباركود موجودًا مسبقًا في قاعدة البيانات
            if (barcodeData[barcode]) {
                console.log("📌 الباركود مكرر، لن يتم إضافته مجددًا:", barcode);
                statusBox.innerHTML = `🔄 الباركود مكرر: ${barcode}`;
            } else {
                barcodeData[barcode] = { firstScanTime: currentTime, status: "✅" };
                successSound.play(); // تشغيل الصوت عند نجاح المسح
                if (navigator.vibrate) navigator.vibrate(200); // اهتزاز الهاتف عند النجاح
                updateDatabase(barcode, "✅", currentTime);
            }

            let elapsedTime = Math.floor((currentTime - barcodeData[barcode].firstScanTime) / 1000);
            let remainingTime = 20 - (elapsedTime - 3);

            if (elapsedTime < 3) {
                barcodeData[barcode].status = "✅";
            } else if (elapsedTime < 23) {
                barcodeData[barcode].status = `⚠️ ${remainingTime}s`;
            } else {
                barcodeData[barcode].status = "❌";
            }

            updateDatabase(barcode, barcodeData[barcode].status, barcodeData[barcode].firstScanTime);
            drawBoundingBox(ctx, code.location, barcodeData[barcode].status);
            statusBox.innerHTML = `${barcodeData[barcode].status} الباركود: ${barcode}`;
        }
    }

    requestAnimationFrame(scan);
}

// ✅ تحسين رسم الإطار حول الباركود
function drawBoundingBox(ctx, location, status) {
    if (!location) return;

    let color = status.includes("✅") ? "green" : status.includes("⚠️") ? "orange" : "red";
    let { topLeftCorner, topRightCorner, bottomRightCorner, bottomLeftCorner } = location;

    ctx.strokeStyle = color;
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(topLeftCorner.x, topLeftCorner.y);
    ctx.lineTo(topRightCorner.x, topRightCorner.y);
    ctx.lineTo(bottomRightCorner.x, bottomRightCorner.y);
    ctx.lineTo(bottomLeftCorner.x, bottomLeftCorner.y);
    ctx.closePath();
    ctx.stroke();

    ctx.fillStyle = color;
    [topLeftCorner, topRightCorner, bottomRightCorner, bottomLeftCorner].forEach(point => {
        ctx.beginPath();
        ctx.arc(point.x, point.y, 5, 0, 2 * Math.PI);
        ctx.fill();
    });

    ctx.fillStyle = "black";
    ctx.font = "bold 30px Arial";
    ctx.textAlign = "center";
    ctx.fillText(status, (topLeftCorner.x + bottomRightCorner.x) / 2, topLeftCorner.y - 10);
}

// ✅ تحديث قاعدة البيانات عند قراءة باركود جديد
async function updateDatabase(barcode, status, time) {
    await fetch("/update_barcode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ barcode, status, time })
    });
}
